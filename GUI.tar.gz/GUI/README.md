GUI
===
Welcome to the [JavaFree/GUI](https://github.com/JavaFree/GUI/wiki) repository!

GUI related Java code.   
This repository is intended for users of the [JavaFree](http://javafree.org/index) 
community, so the main language is Portuguese (Brazil) - Sorry [:-)

Diversos programas relacionados com GUI (Swing, Applet, ...).


Endereços
---------
* https://github.com/JavaFree/GUI.git
* git://github.com/JavaFree/GUI.git

Para criar uma cópia local deste projeto, use o comando   
`git clone git@github.com:JavaFree/GUI.git`    
ou   
`git clone https://github.com/JavaFree/GUI.git`   


Participação
------------

Para poder postar mudanças nesse projeto, crie um 
[Issue](https://github.com/JavaFree/GUI/issues "Issues")
mencionando o nome (e o número) do seu usuário do JavaFree.   


Conteúdo
--------

* [887119](/JavaFree/GUI/issues/1) :
  Exemplo de `JFrame` sem barra de título (sem decoração).

* [887226](/JavaFree/GUI/issues/2) :
  Mostrar uma imagem em um JFrame.

* [887197](/JavaFree/GUI/issues/3): 
  Reação a JComboBox e setar JLabel

* [887254](https://github.com/JavaFree/GUI/issues/5) :
  Exmplo de validação de JTextField. 

* [887790](/JavaFree/GUI/issues/6) :
  MouseMotion para mover janela.

* 887866 :
  Temporizador com tempo variado.
  
* 887869 :
  DUVIDA - while + contador com restriçao em tela de LOGIN
