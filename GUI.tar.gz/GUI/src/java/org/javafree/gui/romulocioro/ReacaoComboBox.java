package org.javafree.gui.romulocioro;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;


/**
 * Demonstração como reagir a uma escolha de um JComboBox e
 * setar um JLabel.
 *
 * @author Carlos Heuberger
 * - <a href="http://javafree.org/viewprofile.jbb?u=5273">cfh</a>
 * @version 1.0, 12.09.2012
 */
public class ReacaoComboBox {

    public static void main(String[] args) {
        new ReacaoComboBox();
    }


    private static final String OPCAO_ADICAO = "Adição";
    private static final String OPCAO_SUBTRACAO = "Subtração";

    private JComboBox<String> comboBox;
    private JLabel pergunta;

    private ReacaoComboBox() {
        comboBox = new JComboBox<>();
        comboBox.setEditable(true);  // permitir a linha seguinte
        comboBox.setSelectedItem("?");  // valor inicial
        comboBox.setEditable(false);  // mas evitar que o usuário escolha algo inexistente
        comboBox.addItem(OPCAO_ADICAO);
        comboBox.addItem(OPCAO_SUBTRACAO);
        comboBox.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ev) {
                comboBox_actionPerformed(ev);
            }
        });

        JPanel panelOperacao = new JPanel();
        panelOperacao.add(new JLabel("Teste de Matemática"));
        panelOperacao.add(comboBox);

        pergunta = new JLabel("escolha uma operação");
        pergunta.setFont(new Font("Dialog", Font.BOLD, 18));
        pergunta.setForeground(Color.BLUE);

        JPanel panelPergunta = new JPanel();
        panelPergunta.add(pergunta);		
        panelPergunta.setBorder(new EmptyBorder(8, 8, 8, 8));

        JFrame frame = new JFrame("Teste de Matemática");
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setLayout(new BorderLayout());
        frame.add(panelOperacao, BorderLayout.BEFORE_FIRST_LINE);
        frame.add(panelPergunta, BorderLayout.CENTER);
        frame.pack();
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }

    private void comboBox_actionPerformed(ActionEvent ev) {
        String operacao = (String) comboBox.getSelectedItem();
        System.out.println(operacao);  // só para conferir
        String valorPergunta;
        switch (operacao) {
            case OPCAO_ADICAO:
                valorPergunta = "uma adição";
                break;
            case OPCAO_SUBTRACAO:
                valorPergunta = "uma subtração";
                break;
            default:
                valorPergunta = "escolha...";
                break;
        }
        pergunta.setText(valorPergunta);
    }
}
