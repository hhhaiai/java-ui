package org.javafree.gui.ismaelAS;

import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.AbstractAction;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.SwingUtilities;

/**
 * eu usei o Undecorated(true) , agora minha janela não se move . 
 * Vi em alguns foruns que tem como passar parâmetros x e y pelo MouseMotion , 
 * mas não entendi bem . Estou começando a usar JFrame ha pouco tempo . 
 * Estou fuçando aqui . Poderiam me dar uma resposta bem simples de como fazer ? . 
 * Tem como fazer pelo Projeto ou só pelo código-fonte mesmo ? . Agradeço
 *
 * @author Carlos Heuberger 
 * @version 1.0, 03.11.2012
 */
public class MoverJanela {

    public static void main(String[] args) {
        new MoverJanela();
    }
    
    ////////////////////////////////////////////////////////////////////////////
    
    private JFrame frame;
    
    private int pressedX;
    private int pressedY;

    
    private MoverJanela() {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                initGUI();
            }
        });
    }

    private void initGUI() {
        JMenuItem close = new JMenuItem(new AbstractAction("Close") {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.dispose();
            }
        });
        
        JMenuBar bar = new JMenuBar();
        bar.add(close);
        
        frame = new JFrame();
        frame.add(new JLabel("Teste"));
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setJMenuBar(bar);
        frame.setUndecorated(true);
        frame.setSize(400, 300);
        frame.validate();
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
        
        MouseAdapter adapter = new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent ev) {
                frameMousePressed(ev);
            }
            @Override
            public void mouseDragged(MouseEvent ev) {
                frameMouseDragged(ev);
            }
        };
        frame.addMouseListener(adapter);
        frame.addMouseMotionListener(adapter);
    }

    private void frameMousePressed(MouseEvent ev) {
        pressedX = ev.getX();
        pressedY = ev.getY();
    }

    private void frameMouseDragged(MouseEvent ev) {
        int dx = ev.getX() - pressedX;
        int dy = ev.getY() - pressedY;
        Point location = frame.getLocation();
        location.translate(dx, dy);
        frame.setLocation(location);
    }
}
