package org.javafree.gui.vrbrant;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.AbstractAction;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.Timer;


/**
 *
 * @author Carlos Heuberger 
 * @version 1.0, 08.11.2012
 */
public class TimerVariavel {

    private JFrame frame;
    private JTextField fieldDelay;
    private JTextField fieldOutput;
    private Timer timer;
    
    public static void main(String[] args) {
        new TimerVariavel();
    }
    
    
    private TimerVariavel() {
        fieldDelay = new JTextField(10);
        fieldDelay.setText("2000");
        fieldDelay.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ev) {
                doChangeDelay();
            }
        });
        
        JPanel panelInput = new JPanel();
        panelInput.add(new JLabel("Delay: "));
        panelInput.add(fieldDelay);
        
        fieldOutput = new JTextField(10);
        fieldOutput.setBackground(Color.LIGHT_GRAY);
        fieldOutput.setEditable(false);
        fieldOutput.setText("0");
        
        JButton change = new JButton(new AbstractAction("Change") {
            @Override
            public void actionPerformed(ActionEvent e) {
                doChangeDelay();
            }
        });
        
        JButton start = new JButton(new AbstractAction("Start") {
            @Override
            public void actionPerformed(ActionEvent e) {
                doStart();
            }
        });
        
        JButton stop = new JButton(new AbstractAction("STOP") {
            @Override
            public void actionPerformed(ActionEvent e) {
                doStop();
            }
        });
        stop.setForeground(Color.RED);
        
        JPanel buttons = new JPanel();
        buttons.add(change);
        buttons.add(start);
        buttons.add(stop);
        
        frame = new JFrame("Timer Variável");
        frame.setLayout(new BorderLayout());
        frame.add(panelInput, BorderLayout.NORTH);
        frame.add(fieldOutput, BorderLayout.CENTER);
        frame.add(buttons, BorderLayout.SOUTH);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.pack();
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
        
        ActionListener action = new ActionListener() {
            private int count = 1;
            @Override
            public void actionPerformed(ActionEvent ev) {
                fieldOutput.setText(count + "  -  " + timer.getDelay());
                count += 1;
                fieldDelay.setBackground(null);
            }
        };
        timer = new Timer(2000, action);
    }

    private void doChangeDelay() {
        String text = fieldDelay.getText();
        if (text == null || text.isEmpty()) {
            fieldDelay.setText(Integer.toString(timer.getDelay()));
            return;
        }
        int delay;
        try {
            delay = Integer.parseInt(text);
        } catch (NumberFormatException ex) {
            Object[] mensagem = { "Número inválido", ex, "tente novamente" };
            JOptionPane.showMessageDialog(frame, mensagem, "Erro", JOptionPane.ERROR_MESSAGE);
            return;
        }
        timer.setDelay(delay);
        fieldDelay.setBackground(Color.LIGHT_GRAY);
    }
    
    private void doStart() {
        fieldOutput.setBackground(null);
        timer.start();
    }
    
    private void doStop() {
        timer.stop();
        fieldOutput.setBackground(Color.LIGHT_GRAY);
    }
}
