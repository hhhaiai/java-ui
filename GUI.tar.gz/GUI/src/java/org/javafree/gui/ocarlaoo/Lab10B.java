package org.javafree.gui.ocarlaoo;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.net.URL;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;

public class Lab10B {

	private static final String IMAGEM = "imagens/ocarlaoo/imagem.jpg";

	public static void main(String[] args) {
		System.out.println(ClassLoader.getSystemResource("."));
		URL url = ClassLoader.getSystemResource(IMAGEM);
		if (url == null) {
			System.err.printf("Imagem \"%s\" n�o encontrada!", IMAGEM);
			return;
		}
		
		final JFrame frame = new JFrame();
		
		JButton gui = new JButton(new ImageIcon(url));
		gui.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				frame.dispose();
			}
		});
		
		frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		frame.setUndecorated(true);
		frame.add(gui);
		frame.pack();
		frame.setLocationRelativeTo(null);
		frame.setVisible(true);
	}
}
