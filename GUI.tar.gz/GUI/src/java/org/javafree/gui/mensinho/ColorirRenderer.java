package org.javafree.gui.mensinho;

import java.awt.Color;
import java.awt.Component;

import javax.swing.JTable;
import javax.swing.table.DefaultTableCellRenderer;

/**
 * Eu tenho uma JTable onde adiciono alguns dados (nomes) nela, como todo mundo.
 * Eu estou mudando a cor da linha conforme o nome. Ex: Se tiver "João" da linha
 * 0 coluna 0, até linha 5 coluna 0, eu quero que estas linhas fiquem vermelhas.
 * Se tiver "Pedro" logo em baixo (ex: linha 6 coluna 0 até linha 10 coluna 0)
 * que quero que fique azul.
 * <P>
 * Copyright: Carlos Heuberger
 *
 * @author Carlos Heuberger
 * @version 1.0, 04.11.2012
 * @see <a href=
 *      "http://javafree.uol.com.br/topic-887801-Problema-ao-mudar-a-cor-de-uma-JTable.html">Problema
 *      ao mudar a cor de uma JTable</a>
 */
public class ColorirRenderer extends DefaultTableCellRenderer {

    private static Color COR_JOAO = new Color(255, 0, 0, 127);
    private static Color COR_PEDRO = new Color(0, 0, 255, 127);

    @Override
    public Component getTableCellRendererComponent(JTable table, Object value, boolean selected, boolean hasFocus,
            int row, int col) {
        super.getTableCellRendererComponent(table, value, selected, hasFocus, row, col);
        switch (String.valueOf(table.getValueAt(row, 0))) {
        case "João":
            setBackground(COR_JOAO);
            break;
        case "Pedro":
            setBackground(COR_PEDRO);
            break;
        default:
            setBackground(null);
            break;
        }
        return this;
    }
}
