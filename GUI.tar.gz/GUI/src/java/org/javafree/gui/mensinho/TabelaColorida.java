package org.javafree.gui.mensinho;

import java.awt.Dimension;

import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.TableModel;

/**
 * Eu tenho uma JTable onde adiciono alguns dados (nomes) nela, como todo mundo. 
 * Eu estou mudando a cor da linha conforme o nome.
 * Ex: Se tiver "João" da linha 0 coluna 0, até linha 5 coluna 0, eu quero que 
 * estas linhas fiquem vermelhas. Se tiver "Pedro" logo em baixo (ex: linha 6 coluna 0 
 * até linha 10 coluna 0) que quero que fique azul.
 * <P>
 * Copyright: Carlos Heuberger
 *
 * @author Carlos Heuberger 
 * @version 1.0, 04.11.2012
 * @see <a href="http://javafree.uol.com.br/topic-887801-Problema-ao-mudar-a-cor-de-uma-JTable.html">Problema ao mudar a cor de uma JTable</a>
 */
public class TabelaColorida {
    
    private JTable table;
    
    private TabelaColorida() {
        TableModel model = createTestModel();
        table = new JTable(model);
        
        TableCellRenderer renderer = new ColorirRenderer();
        table.setDefaultRenderer(Object.class, renderer);
        
        JScrollPane scroll = new JScrollPane(table);
        scroll.setPreferredSize(new Dimension(-1, 150));
        
        JOptionPane.showMessageDialog(null, scroll);
    }

    private TableModel createTestModel() {
        String[] colunas = { "nome", "informação" };
        String[][] dados = {
            { "João" , "info 01" },
            { "João" , "info 02" },
            { "João" , "info 03" },
            { "João" , "info 04" },
            { "João" , "info 05" },
            { "Pedro" , "info 06" },
            { "Pedro" , "info 07" },
            { "Pedro" , "info 08" },
            { "Pedro" , "info 09" },
            { "Pedro" , "info 10" },
            { "Maria" , "info 11" },
            { "Maria" , "info 12" },
            { "Maria" , "info 13" },
            { "Maria" , "info 14" },
            { "Maria" , "info 15" },
            { "Luiz" , "info 16" },
            { "Luiz" , "info 17" },
            { "Luiz" , "info 18" },
            { "Luiz" , "info 19" },
            { "Luiz" , "info 20" }
        };
        return new DefaultTableModel(dados , colunas );
    }
    public static void main(String[] args) {
        new TabelaColorida();
    }
}
