package org.javafree.gui.BlackJoll;

import java.awt.GridLayout;

import javax.swing.InputVerifier;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JTextField;
import javax.swing.text.JTextComponent;

/**
 * Como validar JTextField.
 * <p>
 * Artigo:
 * <a href="http://javafree.uol.com.br/topic-887254-Validacao-instantanea.html">
 * Validação instantânea</a><br>
 * Issue: <a href="https://github.com/JavaFree/GUI/issues/5">887254</a>
 *
 * @author Carlos Heuberger -
 *         <a href="http://javafree.org/viewprofile.jbb?u=5273">cfh</a>
 * @version 1.0, 25.09.2012
 */
public class ValidacaoTextField {

    public static void main(String[] args) {
        InputVerifier verifier = new InputVerifier() {
            @Override
            public boolean verify(JComponent input) {
                JTextComponent field = (JTextComponent) input;
                String value = field.getText();
                if (value.isEmpty()) {
                    return true;
                } else {
                    try {
                        Integer.parseInt(value);
                        return true;
                    } catch (NumberFormatException ex) {
                        return false;
                    }
                }
            }
        };

        JTextField field = new JTextField(10);
        field.setInputVerifier(verifier);

        JFrame frame = new JFrame("Validação");
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setLayout(new GridLayout(0, 1));
        frame.add(field);
        frame.add(new JTextField("campo qualquer"));
        frame.pack();
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }
}
