package org.javafree.gui.danielNO;

import java.awt.event.ActionEvent;

// não tem import javax.swing.border.Border;

import javax.swing.AbstractAction;
import javax.swing.JButton;
import javax.swing.JFrame;

/**
 * Demonstração de um JFrame sem barra de título!
 * <p>
 * Artigo: <a href="http://javafree.uol.com.br/topic-887119-Botao-nao-executa.html">
 *         Botão não executa a função (Resolvido)</a>
 *
 * @author Carlos Heuberger 
 *       - <a href="http://javafree.org/viewprofile.jbb?u=5273">cfh</a>
 * @version 1.0, 21.09.2012
 */
public class SemDecoracao {

    public static void main(String[] args) {
        final JFrame frame = new JFrame("Teste");
        
        JButton fechar = new JButton(new AbstractAction("Fechar") {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.dispose();
            }
        });
        
        frame.add(fechar);
        
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setUndecorated(true);
        frame.setSize(400, 300);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }
}
