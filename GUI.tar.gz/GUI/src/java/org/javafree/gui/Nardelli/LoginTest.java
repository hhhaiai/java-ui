package org.javafree.gui.Nardelli;

import static java.awt.GridBagConstraints.*;

import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;

import javax.swing.AbstractAction;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

/**
 * Bom pessoal, to batendo a cabeça pra fazer algo simples, mas que nao esta encaixando...
 * é simples, tenho uma tela de LOGIN e quero apenas uma restriçao...
 * se o usuario nao acertar o login e senha por 3 vezes ele sai..
 * <P>
 * <a href="http://javafree.uol.com.br/topic-887869-DUVIDA-while-+-contador-com-restricao-em-tela-de-LOGIN.html">
 * DUVIDA - while + contador com restriçao em tela de LOGIN</a>

 *
 * @author Carlos Heuberger 
 * @version 1.0, 08.11.2012
 */
public class LoginTest {

    public static void main(String[] args) {
        new LoginTest();
    }
    
    ////////////////////////////////////////////////////////////////////////////////////////////////
    
    private int tentativas;
    
    private JFrame frame;
    private JTextField user;
    private JPasswordField pass;
    
    private LoginTest() {
        tentativas = 0;
        
        user = new JTextField(20);
        pass = new JPasswordField(20);
        
        JButton button = new JButton(new AbstractAction("login") {
            @Override
            public void actionPerformed(ActionEvent e) {
                doLogin();
            }
        });
        
        frame = new JFrame("Login");
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setLayout(new GridBagLayout());
        add(frame, "Usuário: ", user);
        add(frame, "Senha:   ", pass);
        frame.add(button, new GridBagConstraints(
            RELATIVE, RELATIVE, 2, 1, 0.0, 1.0, CENTER, NONE, new Insets(0, 0, 0, 0), 0, 0));
        frame.pack();
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }

    private void doLogin() {
        if (user.getText().equals("admin") && new String(pass.getPassword()).equals("admin")) {
            // faz login, por exemplo abrir janela principal: Principal.open()
            JOptionPane.showMessageDialog(frame, "logado...");
            frame.dispose();
            return;
        }
        
        tentativas += 1;
        if (tentativas < 3) {
            JOptionPane.showMessageDialog(frame, "Login inválido! Tente novamente.");
            pass.setText(null);
        } else {
            JOptionPane.showMessageDialog(frame, "Sinto muito... ");
            frame.dispose();
            return;
        }
    }

    private void add(JFrame fr, String text, JComponent field) {
        JLabel label = new JLabel(text);
        label.setLabelFor(field);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.anchor = BASELINE_LEADING;
        gbc.fill = HORIZONTAL;
        fr.add(label, gbc);
        gbc.gridwidth = REMAINDER;
        fr.add(field, gbc);
    }
}
